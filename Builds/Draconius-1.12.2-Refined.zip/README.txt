DRACONIUS — A TALON CREATION
Minecraft Java Edition 1.12.2

Designed for the classic 1.12.2 resource-pack format (pack_format 3).
Includes redesigned familiar terrain blocks, diamond armor icons and worn armor layers, and diamond gathering tools.
All ordinary block and item artwork is 16x16; armor atlas textures are 64x32.

Install: place this ZIP in .minecraft/resourcepacks, open Options > Resource Packs, and enable Draconius. Do not extract the ZIP.
